package emsi.ma.studentservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentServicesApplicationTests {

    @Test
    void contextLoads() {
    }

}
