package emsi.ma.studentservices.service;

import emsi.ma.studentservices.entities.Student;

import java.util.List;

public class StudentServiceImp implements IStudentservice{


    @Override
    public List<Student> getStudents() {
        return null;
    }

    @Override
    public Student getStudent(Long id) {
        return null;
    }
}
