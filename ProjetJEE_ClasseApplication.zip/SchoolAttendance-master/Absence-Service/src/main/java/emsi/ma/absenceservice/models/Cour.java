package emsi.ma.absenceservice.models;

import lombok.Data;

@Data

public class Cour {

    private Long id;
    private String name;
    private String annee;
    private int heure;


}
